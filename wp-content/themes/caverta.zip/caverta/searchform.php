<form method="get" id="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>/">
	<span><input type="text" name="s" class="search-string" placeholder="<?php esc_attr_e('type and hit enter', 'caverta')?>"/></span>
</form>
